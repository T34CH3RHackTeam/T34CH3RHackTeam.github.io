hiddenimports = ['sip', 'PyQt4._qt']
