# some modules use the old-style import: explicitly include 
# the new module when the old one is referenced
hiddenimports = ["email.mime.text", "email.mime.multipart"]
