
hiddenimports = ['agile', 'dotnet']